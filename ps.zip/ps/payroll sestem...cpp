// Payroll System (8)
// Justice Gyamfi  
// UEB3250122 
// BSc.Information Technology."C" 
// justicetod44@gmail.com


#include <iostream> 
#include <string>
#include <iomanip>

using namespace std;
 //  Declaration of variables
 
struct employee {
	string name, department;
	int  age;
	char gender;
	float days, rate;	
};

main() {
	
	float solve=0.00; 
	string sex;
	employee user;
	 
	 cout << "\t\tEmployee's Payroll System in C++";
	 cout << "\n\n";
	 cout <<  "\t Created By: Mr. Justice Gyamfi , MAED- IT, MIT";
	 cout <<"\n\n";
	 
 
	 cout <<"Enter the Name of the Employee : ";
	 getline(cin,user.name);
	 
 
	 cout <<"Enter the Name of Department   : ";
	  getline(cin,user.department);
	  
	   
	 cout <<"Enter the gender of the Employee : ";
	 user.gender = getchar();
	 
	 
	 cout << "Enter the Number of Days Worked : ";
	 cin >> user.days;
	 

	 cout << "Enter the Daily Rate  : ";
	 cin >> user.rate;
	 
	 
	 solve = (user.days * user.rate);
	 if (user.gender == 'M' || user.gender == 'm')
	   {
	 	sex = "Male";
	   }
	 else if (user.gender == 'F' || user.gender == 'f')  
	 {
	 	sex = " Female";
	 }
	    
	    
	    
	 cout << fixed;
	 cout << setprecision(2); 
	  cout << "\n\n";
	  cout << "\t ===== GENERATED REPORT =====";
	  cout << "\n\n";
	  cout << "\nEmployee Name : " << user.name;
	  cout << "\nDepartment    : " << user.department;  
	  cout << "\nGender        : " << sex;
	  cout <<" \nSalary        : $ " << solve;
	  cout << "\n\n" ;
	  system("pause");
	  
	  return 0 ;
	  
	  
}













